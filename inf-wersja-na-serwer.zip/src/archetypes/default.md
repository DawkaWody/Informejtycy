---
draft: false
title: 'TYTUŁ ARTYKUŁU'
id: NUMER ARTYKUŁU
nerd: true / false (false jeśli jest podstawowy, true jeśli jest zaawansowany)
---
