# Bajtazar wita świat

Bajtazar, młody programista z królestwa Bajtocji, stawia pierwsze kroki w programowaniu i potrzebuje Twojej pomocy! Jego zadaniem jest napisanie programu, który wypisze na ekranie słynne powitanie z programowaniem: "Hello, World!". Pomożesz mu?