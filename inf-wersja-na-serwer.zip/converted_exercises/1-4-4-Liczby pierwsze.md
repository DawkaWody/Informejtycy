# Liczby pierwsze

Napisz program, który wypisze pierwsze $n$ ($0 < n \le 10^6$) liczb pierwszych. Program powinien sprawdzać każdą liczbę w pętli, czy jest liczbą pierwszą, i wypisać ją, gdy będzie spełniać ten warunek.

#### Wejście:

Pierwsza i jedyna linia wejścia wczytuje liczbę $n$.

#### Wyjście:

W pierwszej linii wyjścia po spacji program wypisuje $n$ liczb pierwszych.

#### Przykład:

**Wejście:**

```
5
```

**Wyjście:**

```
2 3 5 7 11
```
