# Bajtazar wita świat

Bajtazar, młody programista z królestwa Bajtocji, stawia pierwsze kroki w języku C++ i potrzebuje Twojej pomocy! Jego zadaniem jest napisanie programu, który wypisze na ekranie słynne powitanie z programowaniem: "Hello, World!".

Twoim zadaniem jest pomoc Bajtazarowi i stworzenie prostego programu w języku C++, który wypisze tekst: Hello, World!