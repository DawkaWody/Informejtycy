Do Bajtka i Warka dołączył Maciek. Oceń kto z nich jest najwyższy.

## Wejście
Na wejściu znajdują się dwie liczby całkowite $a$ , $b$ i $c$  *( $0 < a , b ,c < 10^5$)* oznaczające wysokości Bartka, Warka i Maćka(w tej kolejności).

## Wyjście
Na wyjściu należy wypisać **"BARTEK"**, **"WAREK"** lub **"MACEK"** w zależności od tego kto z nich jest wyższy. 
P.S. Załóż że są różnej wysokości.

## Przykłady

##### Wejście 1 
```
170
160
190
```

##### Wyjście 1
```
MACEK
```

##### Wejście 2
```
175
173
160
```

##### Wyjście 2
```
BARTEK
```


