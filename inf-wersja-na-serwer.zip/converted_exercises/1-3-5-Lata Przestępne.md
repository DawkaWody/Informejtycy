Warek ma jutro kartkówkę z geografii, na której będzie musiał powiedzieć czy rok wskazany przez nauczyciela jest przestępny. Prosi ciebie o pomoc, chce żebyś napisał program, który na wejście otrzymał by rok a na wyjście wypisał by czy rok jest przestępny. Warek potrzebuje takiego programu żeby ~~ściągnąć~~  poćwiczyć przed kartkówką.
## Wejście
Na wejściu znajdują się jedna liczba całkowita $x$  ($1 < x < 10^5$) oznaczająca rok.
## Wyjście
Na wyjściu należy wypisać **"TAK"**, jeśli rok jest przystępny, bądź **"NIE"** w przypadku jeśli nie jest przestępny.

## Prykłady
##### Wejście 1 
```
2024
```
##### Wyjście 1
```
TAK
```

##### Wejście 2
```
2000
```
##### Wyjście 2
```
NIE
```