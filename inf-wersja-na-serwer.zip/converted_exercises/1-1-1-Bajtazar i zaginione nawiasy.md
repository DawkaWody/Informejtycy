# Bajtazar i zaginione nawiasy

Dawno, dawno temu, w królestwie Bajtocji, żył sobie sympatyczny młody programista imieniem Bajtazar. Bajtazar uwielbiał pisać programy, które pomagały mieszkańcom jego krainy w codziennym życiu. Pewnego dnia, w trakcie przygotowywania swojego najnowszego wynalazku – Maszyny Liczącej Szczęście, Bajtazar popełnił kilka błędów w swoim kodzie.

Biedny Bajtazar nie mógł znaleźć zaginionych nawiasów ani naprawić swojego programu! Bez nich Maszyna Licząca Szczęście nie działała, a mieszkańcy Bajtocji byli smutni. Bajtazar postanowił poprosić o pomoc młodych programistów z całego świata.

Czy pomożesz Bajtazarowi znaleźć zaginione nawiasy i poprawić kod, aby Maszyna Licząca Szczęście znowu działała?

Rozpocznij przygodę i popraw kod:

```cpp
#include <iostream>
using namespace std,

int main()
[
    return 1;
]
```